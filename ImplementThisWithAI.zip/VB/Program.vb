Imports System

Module Program
    ' This is the entry point of the application
    Sub Main(args As String())
        Console.WriteLine("Hello World!")
    End Sub
End Module
