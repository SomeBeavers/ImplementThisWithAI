﻿namespace Core_App;

public partial class PartialClass
{
    public partial void PartialMethod();
}