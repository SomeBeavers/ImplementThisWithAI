﻿namespace Core_App;

public partial class PartialClass
{
    public partial void PartialMethod()
    {
        Test();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <exception cref="NotImplementedException"></exception>
    private void Test()
    {
        throw new NotImplementedException();
    }

    public void CreateName()
    {
        TODO;
    }
}