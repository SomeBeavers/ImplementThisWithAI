﻿namespace Core_App;

public class UsePartialClass
{
    public void UsePartialMethod()
    {
        PartialClass partialClass = new();
        partialClass.PartialMethod();
    }
}