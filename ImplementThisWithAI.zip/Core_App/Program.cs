﻿// created by me
Console.WriteLine("Hello, World!");


int GetSum(int a, int b)// Method to calculate the sum of two integers.
{
	return a + b;
}