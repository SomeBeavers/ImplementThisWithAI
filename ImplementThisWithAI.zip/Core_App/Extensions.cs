﻿namespace Core_App;

public static class Extensions
{
}