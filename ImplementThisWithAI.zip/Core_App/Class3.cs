﻿namespace Core_App;

public class Class34
{
    
}