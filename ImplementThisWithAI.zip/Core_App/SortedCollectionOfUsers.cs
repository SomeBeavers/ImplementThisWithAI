﻿namespace Core_App;

public class SortedCollectionOfUsers
{
    public User this[
        int index]
    {
        get { throw new NotImplementedException(); }
    }
}